// ============================================================================
// Entry points: vertex + fragment
// ============================================================================

@vertex
fn vertex(in: Vertex, @builtin(vertex_index) vertex_index: u32) -> VertexOutput {
  var out: VertexOutput;

  let shading_mode: u32 = effects.shading_mode;
  let normal_mode:  u32 = effects.normal_mode;
  let enable_bent:  u32 = effects.enable_bent;

  // Apply mesh local_to_world ON THE FLAT GRID FIRST to get actual world tile coords
  let world_from_local = mesh_functions::get_world_from_local(in.instance_index);
  var flat_local_pos = in.position;
  flat_local_pos.y = 0.0;
  let flat_world_pos = mesh_functions::mesh_position_local_to_world(world_from_local, vec4<f32>(flat_local_pos, 1.0));

  let wx = i32(round(flat_world_pos.x));
  let wz = i32(round(flat_world_pos.z));
  let final_y = atlas_read_height(wx, wz);

  var final_world_pos = flat_world_pos;
  final_world_pos.y += final_y;

  out.world_position = final_world_pos;
  out.position       = view_transformations::position_world_to_clip(out.world_position.xyz);
  out.uv = in.uv;
  out.instance_index = in.instance_index;

  // Base geometric normal (fast)
  let geometric_normal_local = get_geometric_normal_local(out.world_position.xyz);
  var Nw = mesh_functions::mesh_normal_local_to_world(geometric_normal_local, in.instance_index);

  // Optional smooth/bicubic normal with edge blend to avoid seams
  if (normal_mode == 1u) {
    let smooth_local = get_bicubic_normal(out.world_position.xyz);
    let smooth_world = mesh_functions::mesh_normal_local_to_world(smooth_local, in.instance_index);
    let blend_edge = chunk_edge_blend_factor(out.world_position.x, out.world_position.z);
    Nw = normalize(mix(smooth_world, Nw, blend_edge));
  }

  // Optional bent normal (same as fragment path)
  if (enable_bent == 1u) {
    Nw = get_bent_normal(out.world_position.xyz, Nw);
  }

  out.world_normal = Nw;

  // Classic vertex path: precompute lambert in uv_b.x using the final Nw
  out.uv_b = vec2<f32>(0.0, 0.0);
  if (shading_mode == 0u) {
    out.uv_b.x = get_lambert(Nw, scene.light_direction);
  }

  return out;
}


@fragment
fn fragment(in: VertexOutput) -> @location(0) vec4<f32> {
  let shading_mode   = effects.shading_mode;
  let normal_mode    = effects.normal_mode;
  let enable_bent    = effects.enable_bent;
  let enable_fog     = effects.enable_fog;
  let enable_gloom   = effects.enable_gloom;
  let enable_tonemap = effects.enable_tonemap;
  let enable_grading = effects.enable_grading;
  let enable_blur    = effects.enable_blur;

  let ambient_strength  = effects.ambient_strength;
  let diffuse_strength  = effects.diffuse_strength;
  let specular_strength = effects.specular_strength;
  let rim_strength      = effects.rim_strength;

  let fill_strength     = effects.fill_strength;
  let sharpness_factor  = effects.sharpness_factor;
  let sharpness_mix     = effects.sharpness_mix;

  let blur_strength     = effects.blur_strength;
  let blur_radius       = effects.blur_radius;

  let exposure          = lighting.exposure;

  // Local coords and tile selection
  let uv_in_tile = vec2<f32>(fract(in.world_position.x), fract(in.world_position.z));
  let tile = atlas_read_meta(i32(floor(in.world_position.x)), i32(floor(in.world_position.z)));

  // Base albedo (optionally reconstructed/upscaled, and optionally blurred/sharpened)
  var base_albedo = sample_tile_reconstructed(uv_in_tile, tile);
  if (enable_blur == 1u && blur_strength > 0.001 && blur_radius > 0.0) {
    let blurred = blurred_albedo(uv_in_tile, tile, blur_radius, vec2<f32>(in.world_position.x, in.world_position.z));
    base_albedo = mix(base_albedo, blurred, clamp(blur_strength, 0.0, 1.0));
  }
  if (effects.sharpening_amount > 0.0) {
    base_albedo = apply_sharpening(base_albedo, uv_in_tile, tile, effects.sharpening_amount);
  }
  let base_alpha: f32 = 1.0; // tile textures assumed opaque for terrain

  // Normals: we already computed in vertex and passed in.world_normal.
  // For non-classic modes we can still override with bicubic if desired.
  var Nw = normalize(in.world_normal);
  if (normal_mode == 1u) {
    let smooth_local = get_bicubic_normal(in.world_position.xyz);
    let smooth_world = mesh_functions::mesh_normal_local_to_world(smooth_local, in.instance_index);
    let blend_edge = chunk_edge_blend_factor(in.world_position.x, in.world_position.z);
    Nw = normalize(mix(smooth_world, Nw, blend_edge));
  }
  if (enable_bent == 1u) {
    Nw = get_bent_normal(in.world_position.xyz, Nw);
  }

  // Light & view
  let L = scene.light_direction; // normalized by CPU
  let V = normalize(scene.camera_position - in.world_position.xyz);

  // Shade
  var hdr_rgb = vec3<f32>(0.0);
  if (shading_mode == 0u) {
    hdr_rgb = shade_mode0_classic_vertex(base_albedo, in.uv_b.x, ambient_strength, diffuse_strength);
  } else if (shading_mode == 1u) {
    hdr_rgb = shade_mode1_enhanced_fragment(
      base_albedo, in.world_position.xyz, Nw, V, L,
      ambient_strength, diffuse_strength, sharpness_factor, sharpness_mix,
      fill_strength, rim_strength, specular_strength, enable_gloom
    );
  } else { // 2 = KR-like
    hdr_rgb = shade_mode2_kr_fragment(
      base_albedo, in.world_position.xyz, Nw, V, L,
      ambient_strength, diffuse_strength, sharpness_factor, sharpness_mix,
      fill_strength, rim_strength, specular_strength, enable_gloom
    );
  }

  // Apply global scene lighting scaler (UI: "Global Lighting / Scene Luminosity")
  hdr_rgb *= max(scene.global_lighting, 0.0);

// ----------------------------------------------------------------------------
  // Fog (NEW implementation)
// ----------------------------------------------------------------------------
  // IMPORTANT: UI-controlled inputs are remapped to internal ranges for intuitive control:
  // - lighting.fog_params.x -> distance_density (0..~0.2 in UI) mapped to fog_end distance
  // - lighting.fog_params.y -> height_density (0..~0.2 in UI) mapped to vertical falloff
  // - lighting.fog_params.z -> noise_scale (0..2 in UI) mapped to world noise scale (bigger => coarser clouds)
  // - lighting.fog_params.w -> noise_strength (0..1 in UI) mapped to cloud contrast/detail/coverage
  if (enable_fog == 1u) {
    // Read raw UI uniforms (defensive clamps)
    let dist_density_ui   = clamp(lighting.fog_params.x, 0.0, 1.0);  // user slider 0..0.2 but clamp anyway
    let height_density_ui = clamp(lighting.fog_params.y, 0.0, 1.0);
    let noise_scale_ui    = clamp(lighting.fog_params.z, 0.0, 2.0);
    let noise_strength_ui = clamp(lighting.fog_params.w, 0.0, 1.0);

    // Fog height bias: -1 valley, 0 neutral, +1 high-alt haze
    let hBias = clamp(lighting.gloom_params.w, -1.0, 1.0);
    let high_w = max(hBias, 0.0);
    let low_w  = max(-hBias, 0.0);

    // -------------------------
    // Distance mapping: translate UI density -> fog_end (meters)
    // Small UI values -> very far (clear). Larger UI -> closer fog end.
    // tweak these ranges if your world units are scaled differently.
    let fog_end = mix(6000.0, 40.0, smoothstep(0.0, 0.2, dist_density_ui));
    let fog_start = max(0.0, fog_end * 0.06);
    let d = length(in.world_position.xyz - scene.camera_position);
    // softer ramp for distance-based fog
    let dist_factor = smoothstep(fog_start, fog_end, d);

    // -------------------------
    // Height mapping: UI -> falloff scale in meters (0.2 UI -> short falloff)
    let height_falloff = mix(800.0, 6.0, smoothstep(0.0, 0.2, height_density_ui));
    let y = in.world_position.y;
    var height_term_high = 0.0;
    var height_term_low  = 0.0;
    if (height_density_ui > 1e-6) {
      height_term_high = 1.0 - exp(-max(y, 0.0) / height_falloff);
      height_term_low  = 1.0 - exp(-max(-y, 0.0) / height_falloff);
    }
    let height_factor = clamp(high_w * height_term_high + low_w * height_term_low, 0.0, 1.0);

    // -------------------------
    // Combine distance & height (union) -> base_fog (0..1)
    let base_fog = clamp(dist_factor + height_factor - dist_factor * height_factor, 0.0, 1.0);

    // -------------------------
    // Noise / clouds — robust mapping
    // Map user noise_scale_ui [0..2] to an internal world-scale: smaller value -> finer clouds,
    // larger value -> coarser/bigger clouds. This remapping makes slider intuitive.
    let noise_scale_world = mix(0.004, 0.25, clamp(noise_scale_ui / 2.0, 0.0, 1.0));
    // noise_strength controls contrast/coverage/detail
    let noise_strength = noise_strength_ui;

    // Build wind & time for animation.
    // If scene.time_seconds isn't being updated by the CPU, clouds won't move — see note below.
    let base_time_speed = 0.02; // base slow speed
    let time_speed = base_time_speed + noise_strength * 0.08;
    let t = scene.time_seconds * time_speed;

    // Wind derived from sun direction (perpendicular flow across sun)
    let sun2 = normalize(vec2<f32>(L.x, L.z));
    // defensively handle degenerate light_dir
    var wind = vec2<f32>(0.7, 0.3);
    if (length(sun2) > 1e-5) {
      wind = normalize(vec2<f32>(L.z, -L.x));
    }

    // Sample coords in world meters; domain-warp to break tiling
    // Note: multiply world.xz by noise_scale_world to get appropriate density
    let p0 = (in.world_position.xz * noise_scale_world) + wind * (t * 6.0);

    // Gentle domain warp — smaller strength so we don't over-warp tiny structures
    let warp_strength = 0.4 * noise_strength + 0.08;
    let pWarp = domain_warp(p0, warp_strength);

    // Multi-scale billow FBM to get both big blobs and small fluff
    let n1 = fbm_billow(pWarp * 1.0);
    let n2 = fbm_billow(pWarp * 2.3) * 0.55;
    let n_billow = clamp(n1 * 0.7 + n2 * 0.3, 0.0, 1.0);

    // Control coverage/contrast:
    // - Lower threshold -> more coverage.
    // - width controls softness of cloud edges.
    let base_threshold = mix(0.72, 0.46, noise_strength); // higher noise_strength -> lower threshold -> more clouds
    let edge_width = mix(0.12, 0.20, 1.0 - noise_strength); // stronger noise -> sharper edges (smaller width)
    let cloud_mask = smoothstep(base_threshold, base_threshold + edge_width, n_billow);

    // Baseline ensures there are some clear areas when desired:
    let baseline = mix(0.03, 0.18, 1.0 - noise_strength); // low baseline -> more clear sky by default
    let peak_gain = mix(1.0, 1.8, noise_strength);

    let cloud_mod = baseline + (peak_gain - baseline) * cloud_mask;

    // Combine
    var fog_factor = clamp(base_fog * cloud_mod, 0.0, 1.0);

    // Subtle breathing so it doesn't look totally static; scaled by noise_strength
    let breath = 0.5 + 0.5 * sin(scene.time_seconds * (0.06 + 0.02 * noise_strength) + (hash(in.world_position.xz * 0.11) * 6.2831));
    fog_factor = clamp(fog_factor * mix(0.97, 1.03, (breath - 0.5) * 0.6 * noise_strength), 0.0, 1.0);

    // Final cap set by UI alpha
    let fog_mix = clamp(fog_factor * lighting.fog_color.a, 0.0, 1.0);

    // If user opted out of volumetric noise, fallback to smooth (flat) fog:
    if (USE_VOLUMETRIC_NOISE == 1u) {
      hdr_rgb = mix(hdr_rgb, lighting.fog_color.rgb, fog_mix);
    } else {
      // simple fallback: linearized distance*height blend capped by alpha
      let flat_mix = clamp(base_fog * lighting.fog_color.a, 0.0, 1.0);
      hdr_rgb = mix(hdr_rgb, lighting.fog_color.rgb, flat_mix);
    }
  }

  // Grading (vibrant with neutral contrast) + Tonemap
  var post = hdr_rgb;
  if (enable_grading == 1u) {
    post = grade_color_vibrant(post); // no pre-tonemap clamping
  }
  var final_rgb = post;
  if (enable_tonemap == 1u) {
    final_rgb = tonemap_reinhard_with_exposure(max(post, vec3<f32>(0.0)), exposure);
  }

  final_rgb = max(final_rgb, vec3<f32>(0.0));
  return vec4<f32>(final_rgb, base_alpha);
}
