// ============================================================================
// Atlas & grid helpers
// ============================================================================

const CHUNK_TILE_NUM_DIM: u32 = 8u;
const DATA_GRID_BORDER:  i32 = 2;
const DATA_GRID_SIDE:    i32 = 13;  // DATA_GRID_BORDER + CHUNK_TILE_NUM_DIM + DATA_GRID_BORDER
const MESH_GRID_SIDE:    u32 = 9u;

// Query the world page coordinates and map them through LRU to a physical GPU Array Layer
fn atlas_read_meta(world_x: i32, world_z: i32) -> TileUniform {
  if (world_x < 0 || world_z < 0) {
    return TileUniform(0.0, 0u, 0u, 0u);
  }

  let wx = u32(world_x);
  let wz = u32(world_z);

  let pw = ATLAS.page_texels.x;
  let ph = ATLAS.page_texels.y;

  let page_x = wx / pw;
  let page_y = wz / ph;

  let off_x = wx % pw;
  let off_y = wz % ph;

  let page_index = page_y * ATLAS.world_pages_x + page_x;
  var layer: u32 = 0xFFFFFFFFu;
  if (page_index < 256u) {
    let arr_idx = page_index / 4u;
    let comp = page_index % 4u;
    layer = ATLAS.page_to_layer[arr_idx][comp];
  }

  if (layer >= ATLAS.max_layers) {
    return TileUniform(0.0, 0u, 0u, 0u);
  }

  // Load from Rg16Uint texture array
  let packed = textureLoad(tile_meta_atlas, vec2<i32>(i32(off_x), i32(off_y)), i32(layer), 0);
  let r = packed.x;
  let g = packed.y;

  let layer_idx = r; // contains only texture layer index (16 bit)

  let height_biased = g & 0xFFu;
  let z_i32 = i32(height_biased) - 128;
  let tile_height = f32(z_i32) * 0.1;

  let tex_size = (g >> 8u) & 1u;

  return TileUniform(tile_height, tex_size, layer_idx, 0u);
}

fn atlas_read_height(world_x: i32, world_z: i32) -> f32 {
  return atlas_read_meta(world_x, world_z).tile_height;
}

// Near the chunk edge, blend normals toward the original to hide seams.
fn chunk_edge_blend_factor(world_x: f32, world_z: f32) -> f32 {
  let local_x = fract(world_x / 8.0) * 8.0;
  let local_z = fract(world_z / 8.0) * 8.0;
  let tx = floor(local_x);
  let tz = floor(local_z);
  let dx = min(tx, f32(CHUNK_TILE_NUM_DIM - 1u) - tx);
  let dz = min(tz, f32(CHUNK_TILE_NUM_DIM - 1u) - tz);
  let min_dist = min(dx, dz);
  return 1.0 - smoothstep(0.0, 2.0, min_dist);
}
