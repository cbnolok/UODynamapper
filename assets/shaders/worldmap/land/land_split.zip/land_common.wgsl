// ============================================================================
// Common header and bindings for land shaders
// ============================================================================

#import bevy_pbr::{
  forward_io::{Vertex, VertexOutput},
  mesh_functions,
  view_transformations,
}

// ============================================================================
// Compile-time DEV config (unified DEV_* prefix)
// ============================================================================

const USE_VOLUMETRIC_NOISE: u32 = 1u; // 0=flat fog, 1=domain-warped billow modulation

// ============================================================================
// Bindings / Uniform Layouts
// ============================================================================

struct TileUniform {
  tile_height:   f32,
  texture_size:  u32, // 0=small atlas, 1=big atlas
  texture_layer: u32,
  texture_hue:   u32,
};

struct AtlasParams {
  page_texels: vec2<u32>,
  tiles_per_page: vec2<u32>,
  max_layers: u32,
  world_pages_x: u32,
  _pad: vec2<u32>,
  page_to_layer: array<vec4<u32>, 64>, // Maps 256 logic pages
};

struct SceneUniform {
  camera_position: vec3<f32>,
  time_seconds: f32,
  light_direction: vec3<f32>, // expected normalized by CPU
  // global scene light scaler (pre-tonemap). Default 1.0 from CPU/UI.
  global_lighting: f32,
};

struct LandEffectsUniform {
  // Modes / toggles
  shading_mode:   u32, // 0=Classic (vertex), 1=Enhanced (frag), 2=KR (frag)
  normal_mode:    u32, // 0=geometric, 1=bicubic
  enable_bent:    u32,
  enable_fog:     u32,

  enable_gloom:   u32,
  enable_tonemap: u32,
  enable_grading: u32,
  enable_blur:    u32,

  // NEW: Graphics settings
  enable_linear_filtering: u32,
  reconstruction_mode:     u32,
  sharpening_amount:       f32,
  _pad_graphics:           f32,

  // intensities (grouped to match std140-ish packing)
  ambient_strength:  f32,
  diffuse_strength:  f32,
  specular_strength: f32,
  rim_strength:      f32,

  fill_strength:     f32,
  sharpness_factor:  f32,
  sharpness_mix:     f32,
  blur_strength:     f32,

  blur_radius:       f32,
  _pad_c1:           f32,
  _pad_c2:           f32,
  _pad_c3:           f32,
};

struct LandLightingUniforms {
    light_color: vec3<f32>,
    _pad0: f32,
    ambient_color: vec3<f32>,
    _pad1: f32,
    exposure: f32,
    gamma: f32,
    _pad2: vec2<f32>,
    fill_sky_color: vec4<f32>,
    fill_ground_color: vec4<f32>,
    rim_color: vec4<f32>,
    grade_warm_color: vec4<f32>,
    grade_cool_color: vec4<f32>,
    grade_params: vec4<f32>,
    grade_extra: vec4<f32>,
    gloom_params: vec4<f32>,
    fog_color: vec4<f32>,
    fog_params: vec4<f32>,
};

@group(3) @binding(100) var tex_small_sampler: sampler;
@group(3) @binding(101) var tex_small: texture_2d_array<f32>;
@group(3) @binding(102) var tex_big:   texture_2d_array<f32>;
@group(3) @binding(103) var tile_meta_atlas: texture_2d_array<u32>;
@group(3) @binding(104) var<uniform> ATLAS: AtlasParams;
@group(3) @binding(105) var<uniform> scene:   SceneUniform;
@group(3) @binding(106) var<uniform> effects: LandEffectsUniform;
@group(3) @binding(107) var<uniform> lighting: LandLightingUniforms;
